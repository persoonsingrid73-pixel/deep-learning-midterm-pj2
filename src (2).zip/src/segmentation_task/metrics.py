from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import torch


@dataclass
class SegmentationScores:
    pixel_accuracy: float
    mean_accuracy: float
    miou: float
    per_class_iou: list[float]


class SegmentationMeter:
    def __init__(self, num_classes: int, ignore_index: int = 255) -> None:
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.confusion = torch.zeros((num_classes, num_classes), dtype=torch.int64)

    def update(self, logits: torch.Tensor, target: torch.Tensor) -> None:
        pred = logits.argmax(dim=1).detach().cpu()
        target = target.detach().cpu()
        valid = (target != self.ignore_index) & (target >= 0) & (target < self.num_classes)
        if valid.sum() == 0:
            return
        indices = self.num_classes * target[valid].to(torch.int64) + pred[valid].to(torch.int64)
        hist = torch.bincount(indices, minlength=self.num_classes * self.num_classes)
        self.confusion += hist.reshape(self.num_classes, self.num_classes)

    def compute(self) -> SegmentationScores:
        hist = self.confusion.to(torch.float64)
        correct = torch.diag(hist)
        total = hist.sum()
        pixel_accuracy = (correct.sum() / total).item() if total > 0 else math.nan
        label_total = hist.sum(dim=1)
        pred_total = hist.sum(dim=0)
        mean_accuracy = torch.nanmean(torch.where(label_total > 0, correct / label_total.clamp_min(1), torch.nan)).item()
        union = label_total + pred_total - correct
        iou = torch.where(union > 0, correct / union.clamp_min(1), torch.nan)
        miou = torch.nanmean(iou).item()
        return SegmentationScores(
            pixel_accuracy=float(pixel_accuracy),
            mean_accuracy=float(mean_accuracy),
            miou=float(miou),
            per_class_iou=[float(x) if not torch.isnan(x) else math.nan for x in iou],
        )


def sampled_mean_average_precision(
    labels: list[np.ndarray],
    scores: list[np.ndarray],
    num_classes: int,
) -> float:
    if not labels or not scores:
        return math.nan
    try:
        from sklearn.metrics import average_precision_score
    except Exception:
        return math.nan

    y_true = np.concatenate(labels, axis=0)
    y_score = np.concatenate(scores, axis=0)
    aps: list[float] = []
    for class_index in range(num_classes):
        binary_true = (y_true == class_index).astype(np.uint8)
        if binary_true.max() == 0:
            continue
        aps.append(float(average_precision_score(binary_true, y_score[:, class_index])))
    return float(np.mean(aps)) if aps else math.nan

