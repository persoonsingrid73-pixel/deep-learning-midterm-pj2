from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont

from .data import CLASS_NAMES, StanfordBackgroundDataset, colorize_mask
from .model import UNet


def denormalize(image: torch.Tensor) -> Image.Image:
    mean = torch.tensor([0.485, 0.456, 0.406])[:, None, None]
    std = torch.tensor([0.229, 0.224, 0.225])[:, None, None]
    image = (image.cpu() * std + mean).clamp(0, 1)
    arr = (image.numpy().transpose(1, 2, 0) * 255).astype(np.uint8)
    return Image.fromarray(arr)


def font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/noto/NotoSansMono-Regular.ttf",
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def make_panel(image: Image.Image, gt: Image.Image, pred: Image.Image, sample_id: str) -> Image.Image:
    title_h = 28
    gap = 8
    w, h = image.size
    canvas = Image.new("RGB", (w * 3 + gap * 2, h + title_h), "white")
    draw = ImageDraw.Draw(canvas)
    labels = [f"image {sample_id}", "ground truth", "prediction"]
    for i, item in enumerate([image, gt, pred]):
        x = i * (w + gap)
        draw.text((x + 4, 4), labels[i], fill=(30, 30, 30), font=font(15))
        canvas.paste(item.convert("RGB"), (x, title_h))
    return canvas


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render validation predictions from a trained checkpoint.")
    parser.add_argument("--data-root", type=Path, default=Path("data/iccv09Data"))
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--num-samples", type=int, default=6)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--image-height", type=int, default=240)
    parser.add_argument("--image-width", type=int, default=320)
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    return parser.parse_args()


@torch.no_grad()
def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    model_args = checkpoint.get("args", {})
    base_channels = int(model_args.get("base_channels", args.base_channels))
    model = UNet(num_classes=len(CLASS_NAMES), base_channels=base_channels)
    model.load_state_dict(checkpoint["model"])
    device = torch.device(args.device)
    model.to(device).eval()

    dataset = StanfordBackgroundDataset(
        args.data_root,
        split="val",
        image_size=(args.image_height, args.image_width),
        augment=False,
        limit=args.num_samples,
    )
    for i in range(len(dataset)):
        sample = dataset[i]
        image = sample["image"].unsqueeze(0).to(device)
        logits = model(image)
        pred = logits.argmax(dim=1).squeeze(0).cpu().numpy().astype(np.uint8)
        gt = sample["mask"].numpy().astype(np.uint8)
        panel = make_panel(denormalize(sample["image"]), colorize_mask(gt), colorize_mask(pred), str(sample["id"]))
        panel.save(args.output_dir / f"sample_{i:02d}_{sample['id']}.png")


if __name__ == "__main__":
    main()

