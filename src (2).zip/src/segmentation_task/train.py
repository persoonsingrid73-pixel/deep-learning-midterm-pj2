from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from tqdm import tqdm

from .data import CLASS_NAMES, build_loaders, class_histogram, make_splits, read_split
from .losses import build_loss
from .metrics import SegmentationMeter, sampled_mean_average_precision
from .model import UNet


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a from-scratch U-Net on Stanford Background Dataset.")
    parser.add_argument("--data-root", type=Path, default=Path("data/iccv09Data"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/experiments"))
    parser.add_argument("--experiment-name", type=str, default=None)
    parser.add_argument("--loss", type=str, choices=["ce", "dice", "ce_dice"], default="ce")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--base-channels", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--image-height", type=int, default=240)
    parser.add_argument("--image-width", type=int, default=320)
    parser.add_argument("--val-fraction", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--limit-train", type=int, default=None)
    parser.add_argument("--limit-val", type=int, default=None)
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--amp", action="store_true", help="Use CUDA automatic mixed precision.")
    parser.add_argument("--logger", choices=["none", "wandb", "swanlab"], default="none")
    parser.add_argument("--project", type=str, default="task3-unet-stanford-background")
    parser.add_argument("--max-ap-pixels", type=int, default=200_000)
    parser.add_argument("--resume", type=Path, default=None, help="Resume model weights from a checkpoint.")
    parser.add_argument(
        "--reset-optimizer-on-resume",
        action="store_true",
        help="Load checkpoint weights but start a fresh optimizer/scheduler. Useful when the previous cosine LR reached zero.",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def optional_logger(args: argparse.Namespace, run_dir: Path) -> Any:
    if args.logger == "none":
        return None
    try:
        if args.logger == "wandb":
            import wandb

            os.environ.setdefault("WANDB_MODE", "offline")
            return wandb.init(project=args.project, name=run_dir.name, config=vars(args), dir=str(run_dir))
        import swanlab

        return swanlab.init(project=args.project, experiment_name=run_dir.name, config=vars(args))
    except Exception as exc:
        print(f"[warn] Could not initialize {args.logger}: {exc}. Continue with CSV logging only.")
        return None


def log_external(logger: Any, values: dict[str, float], step: int) -> None:
    if logger is None:
        return
    try:
        if hasattr(logger, "log"):
            logger.log(values, step=step)
        else:
            import swanlab

            swanlab.log(values, step=step)
    except Exception as exc:
        print(f"[warn] external logger failed at epoch {step}: {exc}")


def save_checkpoint(path: Path, model: nn.Module, optimizer: torch.optim.Optimizer, epoch: int, best_miou: float, args: argparse.Namespace) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "best_miou": best_miou,
            "args": vars(args),
            "class_names": CLASS_NAMES,
        },
        path,
    )


def load_checkpoint_for_resume(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    reset_optimizer: bool,
    device: torch.device,
) -> tuple[int, float]:
    checkpoint = torch.load(path, map_location=device)
    model.load_state_dict(checkpoint["model"])
    if not reset_optimizer and "optimizer" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer"])
    start_epoch = int(checkpoint.get("epoch", 0)) + 1
    best_miou = float(checkpoint.get("best_miou", -math.inf))
    print(
        f"Resumed weights from {path}; start_epoch={start_epoch}, "
        f"best_miou={best_miou:.4f}, reset_optimizer={reset_optimizer}"
    )
    return start_epoch, best_miou


def train_one_epoch(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    scaler: torch.amp.GradScaler,
    use_amp: bool,
) -> float:
    model.train()
    total_loss = 0.0
    total_images = 0
    progress = tqdm(loader, desc="train", leave=False)
    for batch in progress:
        image = batch["image"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda", enabled=use_amp):
            logits = model(image)
            loss = criterion(logits, mask)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        batch_size = image.size(0)
        total_loss += float(loss.detach()) * batch_size
        total_images += batch_size
        progress.set_postfix(loss=total_loss / max(total_images, 1))
    return total_loss / max(total_images, 1)


@torch.no_grad()
def validate(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    device: torch.device,
    num_classes: int,
    ignore_index: int,
    max_ap_pixels: int,
) -> dict[str, Any]:
    model.eval()
    total_loss = 0.0
    total_images = 0
    meter = SegmentationMeter(num_classes=num_classes, ignore_index=ignore_index)
    ap_labels: list[np.ndarray] = []
    ap_scores: list[np.ndarray] = []
    sampled_pixels = 0

    for batch in tqdm(loader, desc="val", leave=False):
        image = batch["image"].to(device, non_blocking=True)
        mask = batch["mask"].to(device, non_blocking=True)
        logits = model(image)
        loss = criterion(logits, mask)
        batch_size = image.size(0)
        total_loss += float(loss.detach()) * batch_size
        total_images += batch_size
        meter.update(logits, mask)

        if max_ap_pixels > 0 and sampled_pixels < max_ap_pixels:
            probs = torch.softmax(logits.detach(), dim=1).permute(0, 2, 3, 1).reshape(-1, num_classes)
            labels = mask.detach().reshape(-1)
            valid = labels != ignore_index
            probs = probs[valid]
            labels = labels[valid]
            remaining = max_ap_pixels - sampled_pixels
            if labels.numel() > remaining:
                index = torch.randperm(labels.numel(), device=labels.device)[:remaining]
                labels = labels[index]
                probs = probs[index]
            sampled_pixels += int(labels.numel())
            ap_labels.append(labels.cpu().numpy())
            ap_scores.append(probs.cpu().numpy())

    scores = meter.compute()
    val_map = sampled_mean_average_precision(ap_labels, ap_scores, num_classes=num_classes)
    return {
        "val_loss": total_loss / max(total_images, 1),
        "val_pixel_acc": scores.pixel_accuracy,
        "val_mean_acc": scores.mean_accuracy,
        "val_miou": scores.miou,
        "val_map": val_map,
        "per_class_iou": scores.per_class_iou,
    }


def write_metrics_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flat = {k: v for k, v in row.items() if k != "per_class_iou"}
    flat.update({f"iou_{name}": value for name, value in zip(CLASS_NAMES, row["per_class_iou"])})
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(flat.keys()))
        if not exists:
            writer.writeheader()
        writer.writerow(flat)


def truncate_metrics_from_epoch(path: Path, start_epoch: int) -> None:
    if not path.exists() or start_epoch <= 1:
        return
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = [row for row in reader if int(float(row["epoch"])) < start_epoch]
        fieldnames = reader.fieldnames
    if not fieldnames:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device(args.device)
    image_size = (args.image_height, args.image_width)
    experiment_name = args.experiment_name or args.loss
    run_dir = args.output_dir / experiment_name
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "config.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")

    train_loader, val_loader = build_loaders(
        data_root=args.data_root,
        image_size=image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        val_fraction=args.val_fraction,
        seed=args.seed,
        limit_train=args.limit_train,
        limit_val=args.limit_val,
    )
    split_paths = make_splits(args.data_root, val_fraction=args.val_fraction, seed=args.seed)
    train_ids = read_split(split_paths.train)
    val_ids = read_split(split_paths.val)
    hist = class_histogram(args.data_root, train_ids)
    dataset_info = {
        "train_images": len(train_loader.dataset),
        "val_images": len(val_loader.dataset),
        "all_train_split_images": len(train_ids),
        "all_val_split_images": len(val_ids),
        "class_names": CLASS_NAMES,
        "train_pixel_histogram": hist.tolist(),
        "image_size": image_size,
    }
    (run_dir / "dataset_info.json").write_text(json.dumps(dataset_info, indent=2), encoding="utf-8")

    model = UNet(num_classes=len(CLASS_NAMES), base_channels=args.base_channels).to(device)
    criterion = build_loss(args.loss, num_classes=len(CLASS_NAMES), ignore_index=255)
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    start_epoch = 1
    best_miou = -math.inf
    best_epoch = -1
    if args.resume is not None:
        start_epoch, best_miou = load_checkpoint_for_resume(
            args.resume,
            model,
            optimizer,
            reset_optimizer=args.reset_optimizer_on_resume,
            device=device,
        )
        best_epoch = start_epoch - 1
        if args.reset_optimizer_on_resume:
            for group in optimizer.param_groups:
                group["lr"] = args.lr
    remaining_epochs = max(1, args.epochs - start_epoch + 1)
    scheduler = CosineAnnealingLR(optimizer, T_max=remaining_epochs)
    use_amp = args.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    logger = optional_logger(args, run_dir)

    metrics_path = run_dir / "metrics.csv"
    if args.resume is not None:
        truncate_metrics_from_epoch(metrics_path, start_epoch)
    print(f"Training {experiment_name} on {device}; train={len(train_loader.dataset)}, val={len(val_loader.dataset)}")
    for epoch in range(start_epoch, args.epochs + 1):
        start = time.time()
        train_loss = train_one_epoch(model, train_loader, criterion, optimizer, device, scaler, use_amp)
        metrics = validate(
            model,
            val_loader,
            criterion,
            device,
            num_classes=len(CLASS_NAMES),
            ignore_index=255,
            max_ap_pixels=args.max_ap_pixels,
        )
        scheduler.step()
        row = {
            "epoch": epoch,
            "train_loss": train_loss,
            **metrics,
            "lr": scheduler.get_last_lr()[0],
            "epoch_seconds": time.time() - start,
        }
        write_metrics_row(metrics_path, row)
        log_external(logger, {k: v for k, v in row.items() if isinstance(v, (int, float))}, step=epoch)

        if metrics["val_miou"] > best_miou:
            best_miou = metrics["val_miou"]
            best_epoch = epoch
            save_checkpoint(run_dir / "checkpoints" / "best.pt", model, optimizer, epoch, best_miou, args)
        save_checkpoint(run_dir / "checkpoints" / "last.pt", model, optimizer, epoch, best_miou, args)
        print(
            f"epoch {epoch:03d}/{args.epochs} "
            f"train_loss={train_loss:.4f} val_loss={metrics['val_loss']:.4f} "
            f"val_acc={metrics['val_pixel_acc']:.4f} val_miou={metrics['val_miou']:.4f} "
            f"val_map={metrics['val_map']:.4f}"
        )

    summary = {"best_miou": best_miou, "best_epoch": best_epoch, "metrics_csv": str(metrics_path)}
    (run_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if logger is not None:
        try:
            logger.finish()
        except Exception:
            pass


if __name__ == "__main__":
    main()
