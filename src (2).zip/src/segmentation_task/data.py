from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset


CLASS_NAMES = [
    "sky",
    "tree",
    "road",
    "grass",
    "water",
    "building",
    "mountain",
    "foreground",
]

PALETTE = np.array(
    [
        [128, 196, 255],
        [35, 139, 69],
        [128, 128, 128],
        [124, 196, 82],
        [48, 128, 196],
        [196, 128, 64],
        [128, 96, 196],
        [220, 80, 80],
    ],
    dtype=np.uint8,
)


@dataclass(frozen=True)
class SplitPaths:
    train: Path
    val: Path


def _resample_image() -> int:
    return Image.Resampling.BILINEAR


def _resample_mask() -> int:
    return Image.Resampling.NEAREST


def discover_ids(root: Path) -> list[str]:
    images_dir = root / "images"
    labels_dir = root / "labels"
    if not images_dir.exists() or not labels_dir.exists():
        raise FileNotFoundError(
            f"Expected Stanford Background folders at {root}/images and {root}/labels. "
            "Run scripts/download_stanford_background.py first."
        )
    ids: list[str] = []
    for image_path in sorted(images_dir.glob("*.jpg")):
        sample_id = image_path.stem
        if (labels_dir / f"{sample_id}.regions.txt").exists():
            ids.append(sample_id)
    if not ids:
        raise RuntimeError(f"No image/regions label pairs found under {root}")
    return ids


def make_splits(root: Path, val_fraction: float = 0.2, seed: int = 42) -> SplitPaths:
    split_dir = root / "splits"
    split_dir.mkdir(parents=True, exist_ok=True)
    split_paths = SplitPaths(train=split_dir / "train.txt", val=split_dir / "val.txt")
    if split_paths.train.exists() and split_paths.val.exists():
        return split_paths

    ids = discover_ids(root)
    rng = random.Random(seed)
    rng.shuffle(ids)
    val_count = max(1, int(round(len(ids) * val_fraction)))
    val_ids = sorted(ids[:val_count])
    train_ids = sorted(ids[val_count:])
    split_paths.train.write_text("\n".join(train_ids) + "\n", encoding="utf-8")
    split_paths.val.write_text("\n".join(val_ids) + "\n", encoding="utf-8")
    return split_paths


def read_split(path: Path) -> list[str]:
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def normalize_mask_values(mask: np.ndarray, num_classes: int, ignore_index: int) -> np.ndarray:
    """Map Stanford labels to 0..C-1 and unknown pixels to ignore_index."""
    mask = mask.astype(np.int64, copy=True)
    valid = mask >= 0
    valid_values = mask[valid]
    if valid_values.size and valid_values.min() >= 1 and valid_values.max() <= num_classes:
        mask[valid] -= 1
    invalid = (mask < 0) | (mask >= num_classes)
    mask[invalid] = ignore_index
    return mask


def colorize_mask(mask: np.ndarray, ignore_index: int = 255) -> Image.Image:
    color = np.zeros((*mask.shape, 3), dtype=np.uint8)
    valid = mask != ignore_index
    clipped = np.clip(mask, 0, len(PALETTE) - 1)
    color[valid] = PALETTE[clipped[valid]]
    color[~valid] = np.array([0, 0, 0], dtype=np.uint8)
    return Image.fromarray(color)


class StanfordBackgroundDataset(Dataset[dict[str, torch.Tensor | str]]):
    def __init__(
        self,
        root: str | Path,
        split: str = "train",
        image_size: tuple[int, int] = (240, 320),
        val_fraction: float = 0.2,
        seed: int = 42,
        num_classes: int = 8,
        ignore_index: int = 255,
        augment: bool = True,
        limit: int | None = None,
    ) -> None:
        self.root = Path(root)
        self.images_dir = self.root / "images"
        self.labels_dir = self.root / "labels"
        self.image_size = image_size
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.augment = augment and split == "train"

        splits = make_splits(self.root, val_fraction=val_fraction, seed=seed)
        split_path = splits.train if split == "train" else splits.val
        self.ids = read_split(split_path)
        if limit is not None:
            self.ids = self.ids[:limit]
        if not self.ids:
            raise RuntimeError(f"Split {split!r} is empty at {split_path}")

    def __len__(self) -> int:
        return len(self.ids)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor | str]:
        sample_id = self.ids[index]
        image = Image.open(self.images_dir / f"{sample_id}.jpg").convert("RGB")
        mask_arr = np.loadtxt(self.labels_dir / f"{sample_id}.regions.txt", dtype=np.int64)
        mask_arr = normalize_mask_values(mask_arr, self.num_classes, self.ignore_index)
        mask = Image.fromarray(mask_arr.astype(np.uint8), mode="L")

        if self.augment:
            image, mask = self._augment(image, mask)
        else:
            image, mask = self._resize_pair(image, mask, self.image_size)

        image_tensor = torch.from_numpy(np.asarray(image, dtype=np.float32).transpose(2, 0, 1)) / 255.0
        image_tensor = (image_tensor - torch.tensor([0.485, 0.456, 0.406])[:, None, None]) / torch.tensor(
            [0.229, 0.224, 0.225]
        )[:, None, None]
        mask_tensor = torch.from_numpy(np.asarray(mask, dtype=np.int64))
        return {"image": image_tensor, "mask": mask_tensor, "id": sample_id}

    def _resize_pair(self, image: Image.Image, mask: Image.Image, size: tuple[int, int]) -> tuple[Image.Image, Image.Image]:
        height, width = size
        return (
            image.resize((width, height), _resample_image()),
            mask.resize((width, height), _resample_mask()),
        )

    def _augment(self, image: Image.Image, mask: Image.Image) -> tuple[Image.Image, Image.Image]:
        target_h, target_w = self.image_size
        scale = random.uniform(0.75, 1.35)
        scaled_w = max(target_w, int(round(image.width * scale)))
        scaled_h = max(target_h, int(round(image.height * scale)))
        image = image.resize((scaled_w, scaled_h), _resample_image())
        mask = mask.resize((scaled_w, scaled_h), _resample_mask())

        if scaled_w == target_w:
            left = 0
        else:
            left = random.randint(0, scaled_w - target_w)
        if scaled_h == target_h:
            top = 0
        else:
            top = random.randint(0, scaled_h - target_h)
        image = image.crop((left, top, left + target_w, top + target_h))
        mask = mask.crop((left, top, left + target_w, top + target_h))

        if random.random() < 0.5:
            image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            mask = mask.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        return image, mask


def seed_worker(worker_id: int) -> None:
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed + worker_id)
    random.seed(worker_seed + worker_id)


def build_loaders(
    data_root: str | Path,
    image_size: tuple[int, int],
    batch_size: int,
    num_workers: int,
    val_fraction: float,
    seed: int,
    limit_train: int | None = None,
    limit_val: int | None = None,
) -> tuple[DataLoader, DataLoader]:
    train_dataset = StanfordBackgroundDataset(
        data_root,
        split="train",
        image_size=image_size,
        val_fraction=val_fraction,
        seed=seed,
        augment=True,
        limit=limit_train,
    )
    val_dataset = StanfordBackgroundDataset(
        data_root,
        split="val",
        image_size=image_size,
        val_fraction=val_fraction,
        seed=seed,
        augment=False,
        limit=limit_val,
    )
    generator = torch.Generator()
    generator.manual_seed(seed)
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
        worker_init_fn=seed_worker,
        generator=generator,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
        worker_init_fn=seed_worker,
    )
    return train_loader, val_loader


def class_histogram(root: str | Path, ids: Iterable[str], num_classes: int = 8, ignore_index: int = 255) -> np.ndarray:
    labels_dir = Path(root) / "labels"
    hist = np.zeros(num_classes, dtype=np.int64)
    for sample_id in ids:
        mask = np.loadtxt(labels_dir / f"{sample_id}.regions.txt", dtype=np.int64)
        mask = normalize_mask_values(mask, num_classes=num_classes, ignore_index=ignore_index)
        valid = mask != ignore_index
        hist += np.bincount(mask[valid], minlength=num_classes)[:num_classes]
    return hist

