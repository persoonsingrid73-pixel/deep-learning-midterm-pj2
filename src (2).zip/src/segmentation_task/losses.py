from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class DiceLoss(nn.Module):
    """Multi-class soft Dice loss implemented directly for semantic segmentation."""

    def __init__(self, num_classes: int, ignore_index: int = 255, smooth: float = 1.0) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        valid = target != self.ignore_index
        if valid.sum() == 0:
            return logits.sum() * 0.0

        probs = F.softmax(logits, dim=1)
        safe_target = target.clone()
        safe_target[~valid] = 0
        one_hot = F.one_hot(safe_target, num_classes=self.num_classes).permute(0, 3, 1, 2).float()
        valid_mask = valid.unsqueeze(1).float()
        probs = probs * valid_mask
        one_hot = one_hot * valid_mask

        dims = (0, 2, 3)
        intersection = (probs * one_hot).sum(dims)
        cardinality = (probs + one_hot).sum(dims)
        dice = (2.0 * intersection + self.smooth) / (cardinality + self.smooth)
        return 1.0 - dice.mean()


class CombinedLoss(nn.Module):
    def __init__(
        self,
        num_classes: int,
        ignore_index: int = 255,
        ce_weight: float = 1.0,
        dice_weight: float = 1.0,
    ) -> None:
        super().__init__()
        self.ce = nn.CrossEntropyLoss(ignore_index=ignore_index)
        self.dice = DiceLoss(num_classes=num_classes, ignore_index=ignore_index)
        self.ce_weight = ce_weight
        self.dice_weight = dice_weight

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return self.ce_weight * self.ce(logits, target) + self.dice_weight * self.dice(logits, target)


def build_loss(name: str, num_classes: int, ignore_index: int = 255) -> nn.Module:
    normalized = name.lower().replace("-", "_")
    if normalized in {"ce", "cross_entropy", "crossentropy"}:
        return nn.CrossEntropyLoss(ignore_index=ignore_index)
    if normalized in {"dice", "dice_loss"}:
        return DiceLoss(num_classes=num_classes, ignore_index=ignore_index)
    if normalized in {"ce_dice", "cross_entropy_dice", "combined"}:
        return CombinedLoss(num_classes=num_classes, ignore_index=ignore_index)
    raise ValueError(f"Unknown loss {name!r}; choose ce, dice, or ce_dice")

