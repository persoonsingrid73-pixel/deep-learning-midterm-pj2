from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


COLORS = {
    "ce": (45, 92, 175),
    "dice": (205, 92, 36),
    "ce_dice": (48, 145, 95),
}


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/noto/NotoSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/noto/NotoSansMono-Regular.ttf",
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def read_metrics(path: Path) -> list[dict[str, float]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = []
        for row in reader:
            rows.append({key: float(value) if value not in {"", "nan", "NaN"} else math.nan for key, value in row.items()})
    return rows


def nice_name(name: str) -> str:
    return {"ce": "Cross-Entropy", "dice": "Dice", "ce_dice": "CE + Dice"}.get(name, name)


def draw_chart(series: dict[str, list[tuple[float, float]]], metric: str, output: Path) -> None:
    width, height = 1100, 680
    margin_l, margin_r, margin_t, margin_b = 90, 40, 70, 90
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    title_font = font(28, bold=True)
    tick_font = font(16)
    label_font = font(18)
    draw.text((margin_l, 22), metric, fill=(25, 25, 25), font=title_font)

    all_points = [point for points in series.values() for point in points if not math.isnan(point[1])]
    if not all_points:
        raise RuntimeError(f"No valid points for {metric}")
    min_x = min(x for x, _ in all_points)
    max_x = max(x for x, _ in all_points)
    min_y = min(y for _, y in all_points)
    max_y = max(y for _, y in all_points)
    if min_x == max_x:
        max_x += 1
    if min_y == max_y:
        max_y += 1
    y_pad = (max_y - min_y) * 0.08
    min_y -= y_pad
    max_y += y_pad
    if "acc" in metric.lower() or "miou" in metric.lower() or "map" in metric.lower():
        min_y = max(0.0, min_y)
        max_y = min(1.0, max_y)

    plot_w = width - margin_l - margin_r
    plot_h = height - margin_t - margin_b

    def sx(x: float) -> float:
        return margin_l + (x - min_x) / (max_x - min_x) * plot_w

    def sy(y: float) -> float:
        return margin_t + (max_y - y) / (max_y - min_y) * plot_h

    draw.rectangle((margin_l, margin_t, width - margin_r, height - margin_b), outline=(210, 210, 210), width=2)
    for i in range(6):
        y = min_y + (max_y - min_y) * i / 5
        yy = sy(y)
        draw.line((margin_l, yy, width - margin_r, yy), fill=(235, 235, 235))
        draw.text((12, yy - 9), f"{y:.3f}", fill=(80, 80, 80), font=tick_font)
    for i in range(6):
        x = min_x + (max_x - min_x) * i / 5
        xx = sx(x)
        draw.line((xx, margin_t, xx, height - margin_b), fill=(245, 245, 245))
        draw.text((xx - 16, height - margin_b + 12), f"{x:.0f}", fill=(80, 80, 80), font=tick_font)
    draw.text((width // 2 - 40, height - 45), "epoch", fill=(40, 40, 40), font=label_font)

    legend_x = width - margin_r - 360
    legend_y = 30
    for i, (name, points) in enumerate(series.items()):
        color = COLORS.get(name, (80, 80, 80))
        ly = legend_y + i * 28
        draw.line((legend_x, ly + 10, legend_x + 42, ly + 10), fill=color, width=4)
        draw.text((legend_x + 52, ly), nice_name(name), fill=(35, 35, 35), font=label_font)
        clean = [(sx(x), sy(y)) for x, y in points if not math.isnan(y)]
        if len(clean) >= 2:
            draw.line(clean, fill=color, width=4, joint="curve")
        for x, y in clean:
            draw.ellipse((x - 4, y - 4, x + 4, y + 4), fill=color)

    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot CSV metrics without matplotlib.")
    parser.add_argument("--experiments-dir", type=Path, default=Path("outputs/experiments"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/figures"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    metrics_by_exp: dict[str, list[dict[str, float]]] = {}
    for metrics_path in sorted(args.experiments_dir.glob("*/metrics.csv")):
        metrics_by_exp[metrics_path.parent.name] = read_metrics(metrics_path)
    if not metrics_by_exp:
        raise RuntimeError(f"No metrics.csv files found in {args.experiments_dir}")

    for metric in ["train_loss", "val_loss", "val_pixel_acc", "val_miou", "val_map"]:
        series = {
            name: [(row["epoch"], row[metric]) for row in rows if metric in row]
            for name, rows in metrics_by_exp.items()
        }
        draw_chart(series, metric, args.output_dir / f"{metric}.png")
    print(f"Wrote figures to {args.output_dir}")


if __name__ == "__main__":
    main()

