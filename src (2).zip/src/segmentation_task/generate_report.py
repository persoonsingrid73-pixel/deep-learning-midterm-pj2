from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, JpegImagePlugin  # noqa: F401


FIGURES = ["train_loss.png", "val_loss.png", "val_pixel_acc.png", "val_miou.png", "val_map.png"]


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    project_root = Path(__file__).resolve().parents[2]
    candidates = [
        str(project_root / "assets" / "fonts" / "NotoSansCJKsc-Regular.otf"),
        str(Path.cwd() / "assets" / "fonts" / "NotoSansCJKsc-Regular.otf"),
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
        "/usr/share/fonts/truetype/noto/NotoSansMono-Bold.ttf" if bold else "/usr/share/fonts/truetype/noto/NotoSansMono-Regular.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def read_last_and_best(metrics_csv: Path) -> tuple[dict[str, float], dict[str, float]]:
    with metrics_csv.open(newline="", encoding="utf-8") as handle:
        rows = [
            {key: float(value) if value not in {"", "nan", "NaN"} else math.nan for key, value in row.items()}
            for row in csv.DictReader(handle)
        ]
    best = max(rows, key=lambda row: row.get("val_miou", -math.inf))
    return rows[-1], best


def collect_results(project_root: Path) -> list[dict[str, float | str]]:
    rows = []
    for metrics_csv in sorted((project_root / "outputs" / "experiments").glob("*/metrics.csv")):
        last, best = read_last_and_best(metrics_csv)
        rows.append(
            {
                "loss": metrics_csv.parent.name,
                "best_epoch": best["epoch"],
                "best_miou": best["val_miou"],
                "best_pixel_acc": best["val_pixel_acc"],
                "best_map": best.get("val_map", math.nan),
                "last_loss": last["val_loss"],
            }
        )
    return rows


def fmt(value: float | str) -> str:
    if isinstance(value, str):
        return value
    if math.isnan(value):
        return "N/A"
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    if abs(value) >= 10:
        return f"{value:.1f}"
    return f"{value:.4f}"


def result_table_md(rows: list[dict[str, float | str]]) -> str:
    if not rows:
        return "尚未发现训练结果。运行 `scripts/run_all.sh` 后会自动填充表格。"
    lines = [
        "| Loss | Best Epoch | Val mIoU | Val Pixel Acc | Val mAP(sampled) | Last Val Loss |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {loss} | {best_epoch} | {best_miou} | {best_pixel_acc} | {best_map} | {last_loss} |".format(
                loss=row["loss"],
                best_epoch=fmt(row["best_epoch"]),
                best_miou=fmt(row["best_miou"]),
                best_pixel_acc=fmt(row["best_pixel_acc"]),
                best_map=fmt(row["best_map"]),
                last_loss=fmt(row["last_loss"]),
            )
        )
    return "\n".join(lines)


def build_markdown(project_root: Path) -> str:
    rows = collect_results(project_root)
    dataset_info = {}
    train_config = {}
    for path in sorted((project_root / "outputs" / "experiments").glob("*/dataset_info.json")):
        dataset_info = json.loads(path.read_text(encoding="utf-8"))
        break
    for path in sorted((project_root / "outputs" / "experiments").glob("*/config.json")):
        train_config = json.loads(path.read_text(encoding="utf-8"))
        break
    train_n = dataset_info.get("all_train_split_images", "N/A")
    val_n = dataset_info.get("all_val_split_images", "N/A")
    image_size = dataset_info.get("image_size", [240, 320])
    histogram = dataset_info.get("train_pixel_histogram", [])
    epochs = train_config.get("epochs", "N/A")
    batch_size = train_config.get("batch_size", "N/A")
    lr = train_config.get("lr", "N/A")
    weight_decay = train_config.get("weight_decay", "N/A")
    base_channels = train_config.get("base_channels", 32)
    num_workers = train_config.get("num_workers", "N/A")
    amp = train_config.get("amp", False)

    histogram_text = ", ".join(str(x) for x in histogram) if histogram else "N/A"
    return f"""# 任务三实验报告：从零训练 U-Net 图像分割模型

## 1. 任务与数据集

本实验使用 Stanford Background Dataset 进行 8 类语义分割。数据集共有 715 张室外场景图像，语义标签来自 `labels/*.regions.txt`，类别为 sky、tree、road、grass、water、building、mountain、foreground object。实验中把负数或越界像素设为 ignore，不参与 loss 和指标统计。

采用固定随机种子 42 做 80/20 划分：训练集 {train_n} 张，验证集 {val_n} 张。输入统一 resize/crop 为 {image_size[0]}x{image_size[1]}。训练集启用随机尺度裁剪和水平翻转，验证集只做确定性 resize。训练集像素类别直方图为：{histogram_text}，可见类别分布明显不均衡，因此 Dice Loss 对小类召回有实际意义。

## 2. 模型结构

模型为手写 U-Net，无任何预训练权重。编码器包含 4 次 `MaxPool2d` 下采样，每层使用两次 `3x3 Conv + BatchNorm + ReLU`；解码器使用 `ConvTranspose2d` 上采样，并与对应编码器特征做 skip connection 拼接；最后用 `1x1 Conv` 输出 8 类 logits。本次基础通道数为 {base_channels}，通道宽度依次为 {base_channels}、{base_channels * 2}、{base_channels * 4}、{base_channels * 8}、{base_channels * 16}。

## 3. 损失函数设置

对比三组训练：

- Cross-Entropy Loss：`torch.nn.CrossEntropyLoss(ignore_index=255)`。
- Dice Loss：手写 multi-class soft Dice，先对 logits 做 softmax，再与 one-hot mask 计算 Dice 系数。
- CE + Dice：二者等权相加，兼顾像素级分类稳定性与类别不平衡下的区域重叠优化。

## 4. 训练设置

优化器为 AdamW，learning rate {lr}，weight decay {weight_decay}，cosine decay；本次实际运行 epoch={epochs}、batch size={batch_size}、num workers={num_workers}、AMP={amp}。所有模型均从随机初始化开始训练。训练日志写入 `outputs/experiments/<loss>/metrics.csv`，并支持 `--logger wandb` 或 `--logger swanlab` 进行可视化记录；当前报告同时使用本地 CSV 生成曲线。

## 5. 实验结果

{result_table_md(rows)}

评价指标包含验证集 pixel accuracy、mean accuracy、mIoU，以及从验证像素概率中采样计算的 one-vs-all mAP。分割任务的主要比较指标为 mIoU。

## 6. 曲线与分析

训练曲线见 `outputs/figures/`。通常 Cross-Entropy 收敛更平滑，但容易受大类主导；Dice Loss 更直接优化重叠区域，对小类更敏感，但早期波动更明显；CE + Dice 往往在稳定性和类别不平衡之间取得更好的折中。本次已从 10 epoch 的最佳检查点继续训练到 40 epoch，比较时以最佳验证 mIoU 为主。

## 7. 复现方式

```bash
cd /xs-train-nas/ys/Lavender/garbage/task3_unet_segmentation
export PYTHON=/xs-train-nas/ys/Lavender/garbage/alignaudit/.conda/bin/python
EPOCHS=10 BATCH_SIZE=16 bash scripts/run_all.sh
TOTAL_EPOCHS=40 LR=0.0001 BATCH_SIZE=16 bash scripts/continue_training.sh
```

单独运行某个 loss：

```bash
PYTHONPATH=src $PYTHON -m segmentation_task.train --data-root data/iccv09Data --loss ce_dice --experiment-name ce_dice --epochs {epochs} --batch-size {batch_size} --amp
```

数据集来源：Stanford DAGS Lab `http://dags.stanford.edu/data/iccv09Data.tar.gz`；论文引用：S. Gould, R. Fulton, D. Koller, *Decomposing a Scene into Geometric and Semantically Consistent Regions*, ICCV 2009。
"""


def wrap_text(text: str, draw: ImageDraw.ImageDraw, max_width: int, current_font: ImageFont.ImageFont) -> list[str]:
    lines: list[str] = []
    for paragraph in text.splitlines():
        if not paragraph:
            lines.append("")
            continue
        current = ""
        for char in paragraph:
            candidate = current + char
            if draw.textlength(candidate, font=current_font) <= max_width:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = char
        if current:
            lines.append(current)
    return lines


def markdown_to_pdf(md: str, pdf_path: Path, figures_dir: Path) -> None:
    page_w, page_h = 1240, 1754
    margin = 90
    line_gap = 10
    pages: list[Image.Image] = []
    current = Image.new("RGB", (page_w, page_h), "white")
    draw = ImageDraw.Draw(current)
    y = margin

    def new_page() -> None:
        nonlocal current, draw, y
        pages.append(current)
        current = Image.new("RGB", (page_w, page_h), "white")
        draw = ImageDraw.Draw(current)
        y = margin

    for raw_line in md.splitlines():
        if raw_line.startswith("```"):
            continue
        if raw_line.startswith("# "):
            f = font(34, bold=True)
            lines = wrap_text(raw_line[2:], draw, page_w - 2 * margin, f)
            spacing = 16
        elif raw_line.startswith("## "):
            f = font(26, bold=True)
            lines = wrap_text(raw_line[3:], draw, page_w - 2 * margin, f)
            spacing = 14
        elif raw_line.startswith("|"):
            f = font(17)
            lines = wrap_text(raw_line, draw, page_w - 2 * margin, f)
            spacing = 8
        else:
            f = font(20)
            lines = wrap_text(raw_line, draw, page_w - 2 * margin, f)
            spacing = line_gap
        for line in lines:
            bbox = draw.textbbox((0, 0), line or " ", font=f)
            line_h = bbox[3] - bbox[1] + spacing
            if y + line_h > page_h - margin:
                new_page()
            draw.text((margin, y), line, fill=(20, 20, 20), font=f)
            y += line_h
        if not lines:
            y += 18

    for figure_name in FIGURES:
        figure_path = figures_dir / figure_name
        if not figure_path.exists():
            continue
        if y > margin + 80:
            new_page()
        title_f = font(26, bold=True)
        draw.text((margin, y), figure_name, fill=(20, 20, 20), font=title_f)
        y += 50
        figure = Image.open(figure_path).convert("RGB")
        max_w = page_w - 2 * margin
        max_h = page_h - y - margin
        figure.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        current.paste(figure, (margin, y))
        y += figure.height + 40

    pages.append(current)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    pages[0].save(pdf_path, save_all=True, append_images=pages[1:], resolution=150.0)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Markdown and PDF report.")
    parser.add_argument("--project-root", type=Path, default=Path("."))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = args.project_root.resolve()
    report_dir = project_root / "report"
    report_dir.mkdir(parents=True, exist_ok=True)
    md = build_markdown(project_root)
    md_path = report_dir / "task3_unet_report.md"
    pdf_path = report_dir / "task3_unet_report.pdf"
    md_path.write_text(md, encoding="utf-8")
    markdown_to_pdf(md, pdf_path, project_root / "outputs" / "figures")
    print(f"Wrote {md_path}")
    print(f"Wrote {pdf_path}")


if __name__ == "__main__":
    main()
