#!/usr/bin/env bash
set -euo pipefail

PYTHON="${PYTHON:-/xs-train-nas/ys/Lavender/garbage/alignaudit/.conda/bin/python}"
export PYTHONPATH="${PWD}/src:${PYTHONPATH:-}"

"${PYTHON}" scripts/download_stanford_background.py

COMMON=(
  --data-root data/iccv09Data
  --output-dir outputs/experiments
  --epochs "${EPOCHS:-30}"
  --batch-size "${BATCH_SIZE:-8}"
  --lr "${LR:-0.0003}"
  --base-channels "${BASE_CHANNELS:-32}"
  --num-workers "${NUM_WORKERS:-4}"
  --amp
  --logger "${LOGGER:-none}"
)

"${PYTHON}" -m segmentation_task.train "${COMMON[@]}" --loss ce --experiment-name ce
"${PYTHON}" -m segmentation_task.train "${COMMON[@]}" --loss dice --experiment-name dice
"${PYTHON}" -m segmentation_task.train "${COMMON[@]}" --loss ce_dice --experiment-name ce_dice

"${PYTHON}" -m segmentation_task.plot_results --experiments-dir outputs/experiments --output-dir outputs/figures
"${PYTHON}" -m segmentation_task.generate_report --project-root "${PWD}"

