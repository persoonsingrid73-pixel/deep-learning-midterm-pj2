#!/usr/bin/env bash
set -euo pipefail

PYTHON="${PYTHON:-/xs-train-nas/ys/Lavender/garbage/alignaudit/.conda/bin/python}"
export PYTHONPATH="${PWD}/src:${PYTHONPATH:-}"

TOTAL_EPOCHS="${TOTAL_EPOCHS:-40}"
BATCH_SIZE="${BATCH_SIZE:-16}"
LR="${LR:-0.0001}"
BASE_CHANNELS="${BASE_CHANNELS:-32}"
NUM_WORKERS="${NUM_WORKERS:-4}"

for LOSS in ce dice ce_dice; do
  "${PYTHON}" -m segmentation_task.train \
    --data-root data/iccv09Data \
    --output-dir outputs/experiments \
    --loss "${LOSS}" \
    --experiment-name "${LOSS}" \
    --epochs "${TOTAL_EPOCHS}" \
    --batch-size "${BATCH_SIZE}" \
    --lr "${LR}" \
    --base-channels "${BASE_CHANNELS}" \
    --num-workers "${NUM_WORKERS}" \
    --amp \
    --resume "outputs/experiments/${LOSS}/checkpoints/best.pt" \
    --reset-optimizer-on-resume
done

"${PYTHON}" -m segmentation_task.plot_results --experiments-dir outputs/experiments --output-dir outputs/figures
"${PYTHON}" -m segmentation_task.generate_report --project-root "${PWD}"

