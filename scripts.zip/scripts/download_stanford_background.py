from __future__ import annotations

import argparse
import tarfile
import urllib.request
from pathlib import Path


URL = "http://dags.stanford.edu/data/iccv09Data.tar.gz"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Download and extract Stanford Background Dataset.")
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--url", type=str, default=URL)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    archive = args.data_dir / "iccv09Data.tar.gz"
    target = args.data_dir / "iccv09Data"
    if not archive.exists():
        print(f"Downloading {args.url} -> {archive}")
        urllib.request.urlretrieve(args.url, archive)
    else:
        print(f"Using existing archive {archive}")
    if not target.exists():
        print(f"Extracting {archive} -> {args.data_dir}")
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(args.data_dir)
    else:
        print(f"Dataset already extracted at {target}")


if __name__ == "__main__":
    main()

